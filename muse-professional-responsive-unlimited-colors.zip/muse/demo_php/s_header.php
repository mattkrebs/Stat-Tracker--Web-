<!doctype html>
<!--[if lt IE 7 ]> <html lang="en-us" class="ie6"> <![endif]-->
<!--[if IE 7 ]>    <html lang="en-us" class="ie7"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en-us" class="ie8"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en-us" class="ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--> <html lang="en-us"> <!--<![endif]-->

<head>
	<meta http-equiv="X-UA-Compatible" content="IE=Edge;chrome=1" >
	<meta charset="utf-8" />

        <link rel="apple-touch-con" href="" />

	<title>Muse Admin Panel</title>

        <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0">

	<!-- The Columnal Grid and mobile stylesheet -->
        <link rel="stylesheet" href="assets/styles/columnal/columnal.css" type="text/css" media="screen" />

	<!-- Fixes for IE -->
        
	<!--[if lt IE 9]>
            <link rel="stylesheet" href="assets/styles/columnal/ie.css" type="text/css" media="screen" />
            <link rel="stylesheet" href="assets/styles/ie8.css" type="text/css" media="screen" />
            <script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE9.js"></script>
            <script type="text/javascript" src="assets/scripts/flot/excanvas.min.js"></script>
	<![endif]-->        
	
	<!-- Now that all the grids are loaded, we can move on to the actual styles. --> 
        <link rel="stylesheet" href="assets/scripts/jqueryui/jqueryui.css" type="text/css" media="screen" />
        <link rel="stylesheet" href="assets/styles/style.css" type="text/css" media="screen" />
        <link rel="stylesheet" href="assets/styles/global.css" type="text/css" media="screen" />
        <link rel="stylesheet" href="assets/styles/config.css" type="text/css" media="screen" />
        
        <!-- Use CDN on production server -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.4/jquery.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.16/jquery-ui.min.js"></script>
        <!-- <script src="assets/scripts/jquery-1.6.4.min.js"></script> -->
        <!-- <script src="assets/scripts/jqueryui/jquery-ui-1.8.16.custom.min.js"></script> -->
        
        <!-- Adds HTML5 Placeholder attributes to those lesser browsers (i.e. IE) -->
        <script type="text/javascript" src="assets/scripts/jquery.placeholder.1.2.min.shrink.js"></script>
        
        <!-- Menu -->
        <link rel="stylesheet" href="assets/scripts/superfish/superfish.css" type="text/css" media="screen" />
        <script src="assets/scripts/superfish/superfish.js"></script>
        
        <!-- Adds charts -->
        <script type="text/javascript" src="assets/scripts/flot/jquery.flot.min.js"></script>
        <script type="text/javascript" src="assets/scripts/flot/jquery.flot.pie.min.js"></script>
        <script type="text/javascript" src="assets/scripts/flot/jquery.flot.stack.min.js"></script>
        
        
         <!-- Form Validation Engine -->
        <script src="assets/scripts/formvalidator/jquery.validationEngine.js"></script>
        <script src="assets/scripts/formvalidator/jquery.validationEngine-en.js"></script>
        <link rel="stylesheet" href="assets/scripts/formvalidator/validationEngine.jquery.css" type="text/css" media="screen" />
        
        <!-- Sortable, searchable DataTable -->
        <script src="assets/scripts/jquery.dataTables.min.js"></script>
        
        <!-- Custom Tooltips -->
        <script src="assets/scripts/twipsy.js"></script>
        
        <!-- WYSIWYG Editor -->
        <script src="assets/scripts/cleditor/jquery.cleditor.min.js"></script>
        <link rel="stylesheet" href="assets/scripts/cleditor/jquery.cleditor.css" type="text/css" media="screen" />
        
        <!-- Form Validation Engine -->
        <script src="assets/scripts/formvalidator/jquery.validationEngine.js"></script>
        <script src="assets/scripts/formvalidator/jquery.validationEngine-en.js"></script>
        <link rel="stylesheet" href="assets/scripts/formvalidator/validationEngine.jquery.css" type="text/css" media="screen" />
        
        <!-- Fullsized calendars -->
        <link rel="stylesheet" href="assets/scripts/fullcalendar/fullcalendar.css" type="text/css" media="screen" />
        <link rel="stylesheet" href="assets/scripts/fullcalendar/fullcalendar.print.css" type="text/css" media="print" />
        <script src="assets/scripts/fullcalendar/fullcalendar.min.js"></script>
        <script src="assets/scripts/fullcalendar/gcal.js"></script>
        
        <!-- Colorbox is a lightbox alternative-->
        <script src="assets/scripts/colorbox/jquery.colorbox-min.js"></script>
        <link rel="stylesheet" href="assets/scripts/colorbox/colorbox.css" type="text/css" media="screen" />

        <!-- Colorpicker -->
        <script src="assets/scripts/colorpicker/colorpicker.js"></script>
         <script src="assets/scripts/muse.js"></script>
        <link rel="stylesheet" href="assets/scripts/colorpicker/colorpicker.css" type="text/css" media="screen" />
        
        <!-- Uploadify -->
        <script type="text/javascript" src="assets/scripts/uploadify/jquery.uploadify.v2.1.4.min.js"></script>
        <script type="text/javascript" src="assets/scripts/uploadify/swfobject.js"></script>
        <link rel="stylesheet" href="assets/scripts/uploadify/uploadify.css" type="text/css" media="screen" />
        
         <!-- All the js used in the demo -->
         <script src="assets/scripts/demo.js"></script>

</head>
<body class="full_width">

<div id="sidebar" class="mobile-hide">
    <div id="faux_header">
        <a href="index.php?sidebar" id="logo">Muse</a>
    </div>
    <nav>
        <ul class="sf-menu mobile-hide row clearfix">
            <li class="active iconed">
                <a href="index.php?sidebar"><span><img src="assets/images/header/icon_dashboard.png" /> Dashboard</span></a>
            </li>
            <li><a href="tables.php?sidebar"><span><img src="assets/images/header/ico_table.png" /> Tables</span></a></li>
            <li><a href="forms.php?sidebar"><span><img src="assets/images/header/ico_form.png" /> Forms</span></a>
                <ul>
                    <li><a href="forms.php?t=forms"><span>Form Styles</span></a></li>
                    <li><a href="dialogbox.php?t=forms"><span>Dialog Boxes</span></a></li>
                </ul>
            </li>
            <li><a href="statistics.php?sidebar"><span><img src="assets/images/header/ico_chart.png" /> Statistics</span></a></li>
            <li><a href="gallery.php?sidebar"><span><img src="assets/images/header/ico_gallery.png" /> Gallery</span></a></li>
            <li><a href="typography.php?sidebar"><span><img src="assets/images/header/ico_typo.png" /> Typography</span></a></li>
            <li><a href="#"><span><img src="assets/images/header/ico_layout.png" /> Layout</span></a>
                <ul>
                    <li><a href="index.php">Liquid</a></li>
                    <li><a href="index.php?sidebar">Sidebar</a></li>
                </ul>
            </li>
            <li><a href="grids.php?sidebar"><span><img src="assets/images/header/ico_grid.png" /> Grid</span></a></li>
            <li><a href="calendar.php?sidebar"><span><img src="assets/images/header/ico_calendar.png" /> Calendar</span></a></li>
            <li><a href="icons.php?sidebar"><span><img src="assets/images/header/ico_icons.png" /> Icons</span></a></li>
        </ul>
    </nav>
</div>

<div id="wrap" class="sidebarred">
	<div id="main">
            <header class="container">
                <div class="row clearfix">
                    
                    <div class="left mobile-only">
                        <a href="index.php?sidebar" id="logo">Muse</a>
                    </div>
                    
                    <div class="right">
                        
                        <ul id="toolbar">
                            <li><span>Logged in as</span> <a class="user" href="#">Administrator</a> <a id="loginarrow" href="#"></a></li>
                            <li><a id="messages" href="#">Messages</a></li>
                            <li><a id="settings" href="#">Settings</a></li>
                            <li><a id="search" href="#">Search</a></li>
                        </ul>

                        <div id="logindrop">
                            <ul>
                                <li><a href="#">Edit Profile</a></li>
                                <li><a href="#">Logout</a></li>
                            </ul>
                        </div>
                    </div>

                </div>
            </header>
            <nav class="container mobile-only">
                <select class="mobile-only row clearfix" onchange="window.open(this.options[this.selectedIndex].value,'_top')">
                    <option value="index.php?sidebar">Dashboard</option>
                    <option value="tables.php?sidebar">Tables</option>
                    <option value="forms.php?sidebar">Forms</option>
                    <option value="statistics.php?sidebar">Statistics</option>
                    <option value="gallery.php?sidebar">Gallery</option>
                    <option value="typography.php?sidebar">Typography</option>
                    <option value="grids.php?sidebar">Grid</option>
                    <option value="calendar.php?sidebar">Calendar</option>
                    <option value="icons.php?sidebar">Icons</option>
                </select>
            </nav>
                        
            <a class="trigger demo_4" href="#">Customize!</a>

            <div id="aurora_option" class="form panel">

                <div class="clearfix">
                    <label>Select Preset</label>
                    <div class="input">
                        <select id="preset" onchange="changePreset()">
                            <option value="#292929,#454545,#0774a7,header_blueprint.png,none">Default</option>
                            <option value="#16331f,#25781a,#216f47,11.png,none">Green Earth</option>
                            <option value="#4d1919,#702929,#662222,7.png,none">Royal Red</option>
                            <option value="#2d354d,#3b4966,#606060,2.png,brushed_alu.png">Ice Blue</option>
                            <option value="#29231b,#4d3d2c,#5e553d,header_blueprint.png,stucco.png">Chocolate Brown</option>
                            <option value="#291325,#322236,#382f38,2.png,diagonal-noise.png">King's Garment</option>
                        </select>
                    </div>
                </div>

                <span id="aurora_or">or <span>make your own!</span></span>

                <div class="clearfix">
                    <label>Header Color</label>
                    <div class="input">
                        <div id="in-header" class="picker"></div>
                    </div>
                </div>
                <div class="clearfix">
                    <label>Navigation Color</label>
                    <div class="input">
                        <div id="in-nav" class="picker"></div>
                    </div>
                </div>
                <div class="clearfix">
                    <label>Title Color</label>
                    <div class="input">
                        <div id="in-title" class="picker"></div>
                    </div>
                </div>
                <div class="clearfix">
                    <label>Title Pattern</label>
                    <div class="input">
                        <select id="titlepattern" onchange="changeTitlePattern()">
                            <option value="none">None</option>
                            <option value="header_blueprint.png">Blueprint</option>
                            <option value="1.png">Pattern 1</option>
                            <option value="2.png">Pattern 2</option>
                            <option value="3.png">Pattern 3</option>
                            <option value="4.png">Pattern 4</option>
                            <option value="5.png">Pattern 5</option>
                            <option value="6.png">Pattern 6</option>
                            <option value="7.png">Pattern 7</option>
                            <option value="8.png">Pattern 8</option>
                            <option value="9.png">Pattern 9</option>
                            <option value="10.png">Pattern 10</option>
                            <option value="11.png">Pattern 11</option>
                        </select>
                    </div>
                </div>
                <div class="clearfix">
                    <label>Background Pattern</label>
                    <div class="input">
                        <select id="backgroundpattern" onchange="changeBGPattern()">
                            <option value="none">None</option>
                            <option value="body_blueprint.png">Blueprint</option>
                            <option value="stucco.png">Stucco</option>
                            <option value="noise.png">Noise</option>
                            <option value="brushed_alu.png">Brushed Aluminium</option>
                            <option value="beige_paper.png">Beige Paper</option>
                            <option value="concrete_wall.png">Concrete Wall</option>
                            <option value="diagonal-noise.png">Diagonal Noise</option>
                            <option value="noisy.png">Noisy</option>
                        </select>
                    </div>
                </div>
            </div>