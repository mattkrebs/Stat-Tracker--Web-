<?php
if(isset($_GET['sidebar'])){
    include('s_header.php');
} else {
    include('header.php');
}
?>

<div id="titlediv">
    <div class="clearfix container" id="pattern">
        <div class="row">
            <div class="col_12">
                <ul class="breadcrumbs hor-list">
                    <li><a href="index.php">Dashboard</a></li>
                    <li><a href="typography.php">Typography</a></li>
                </ul>
                <h1>Typography</h1>
            </div>
        </div>
    </div>
</div>

<div class="container" id="actualbody">

<div class="row">
    <div class="widget clearfix">
        <h2>Basic Styles</h2>
        <div class="widget_inside">
            <div class="col_12">
                <div class="col_9 clearfix">
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href="#">Phasellus auctor placerat euismod.</a> Nam vel felis ipsum, ac tincidunt purus. <strong>Etiam dictum massa sed neque tincidunt tincidunt.</strong> <em>Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.</em> <span class="underline">Curabitur at mi sed augue ullamcorper mattis ut id leo.</span> Proin laoreet nisl sed erat porttitor at suscipit tellus consectetur. Curabitur pretium tortor vitae velit tincidunt aliquet. Maecenas eget elit id orci molestie porta. Pellentesque aliquet luctus ligula at bibendum. Aenean rhoncus urna varius erat fringilla adipiscing. Proin ullamcorper sapien at lectus vulputate id hendrerit dolor tempus. Ut consectetur, sem sit amet aliquam ultrices, tellus sapien adipiscing lorem, non vulputate sem sapien in dolor. Morbi id mauris enim. Curabitur ultrices, dolor et congue faucibus, metus lectus ornare purus, eget pharetra nulla leo at neque. Pellentesque in ligula non sapien fermentum accumsan. </p>
                </div>
                <div class="col_3 last">
                    <h2>Heading 2</h2>
                    <h3>Heading 3</h3>
                    <h4>Heading 4</h4>
                    <h5>Heading 5</h5>
                    <h6>Heading 6</h6>
                </div>
            </div>
            <div class="col_12 clearfix">
            <div class="col_6">
                <h3 class="padding_bottom_15">List Item</h3>
                <div class="col_3">
                    <ul class="disc">
                        <li>List Item 1</li>
                        <li>List Item 2</li>
                        <li>List Item 3</li>
                        <li>List Item 4</li>
                        <li>List Item 5
                            <ul>
                                <li>List Item 1</li>
                                <li>List Item 2</li>
                            </ul>
                        </li>
                        <li>List Item 6</li>
                    </ul>
                </div>
                <div class="col_3 last">
                    <ol class="numbered">
                        <li>List Item 1</li>
                        <li>List Item 2</li>
                        <li>List Item 3</li>
                        <li>List Item 4</li>
                        <li>List Item 5
                            <ol class="numbered">
                                <li>List Item 1</li>
                                <li>List Item 2</li>
                            </ol>
                        </li>
                        <li>List Item 6</li>
                    </ol>
                </div>
            </div>
            <div class="col_6 last">
                <h3 class="padding_bottom_15">Blockquote</h3>
                <blockquote>Twenty years from now you will be more disappointed by the things that you didn't do than by the ones you did do. So throw off the bowlines. Sail away from the safe harbor. Catch the trade winds in your sails. Explore. Dream. Discover.
                    <cite>Mark Twain</cite>
                </blockquote>
            </div>
            </div>
            <div class="col_12 clearfix">
                <div class="col_6">
                    <h3>Pre Block</h3>
<pre>
    amount = 0
    try:
        try:
            while True:
                woodchuck.chuck(wood)
                amount += 1
        except ValueError, e:
            print "It can chuck up to %d" % amount
    except AttributeError, e:
        print "None, sadly."
</pre>
                </div>
                <div class="col_6 last">
                    <h3>Code Block</h3>
                    
<pre><code>    amount = 0
    try:
        try:
            while True:
                woodchuck.chuck(wood)
                amount += 1
        except ValueError, e:
            print "It can chuck up to %d" % amount
    except AttributeError, e:
        print "None, sadly."
</code></pre>
                    </div>
                </div>

            <div class="col_12 clearfix">
                <h3 class="padding_bottom_15">Images</h3>
                <p>Images or video wider than the column it is in will shrink to fit. Don't define image width or height inline, and good to go.</p>
                <div class="col_6">
                    <img src="demo/5.jpg" title="Photo credit: Hasin Hayder" />
                    <p class="center">Hi. I am an image caption <br />
                        <code>p class='center'</code></p>
                </div>
                <div class="col_6 last">
                    <img src="demo/8.jpg" title="Photo credit: Hasin Hayder" />
                    <p class="align-right">Hi. I am an image caption which is right aligned <br />
                        <code>p class='align-right'</code></p>
                </div>
            </div>

            </div>
        </div>
    </div>
    
<div class="row">
    <div class="widget">
        <h2>Notifications</h2>
        <div class="widget_inside">
            <span class="notification undone">
                This is a red notification with class="notification undone"
            </span>
            <span class="notification done">
                This is a green notification with class="notification done"
            </span>
            <span class="notification information">
                This is a blue notification with class="notification information"
            </span>
            <span class="notification setting">
                This is a grey notification with class="notification settings"
            </span>
            <span class="notification warning">
                This is a yellow notification with class="notification warning"
            </span>
        </div>
    </div>
</div>
    
<div class="row">
    <div class="widget">
        <h2>Buttons</h2>
        <div class="widget_inside clearfix">
            <div class="col_12 clearfix">
                <div class="col_4">
                    <a href="#" class="small button"><span>Small Button</span></a>
                    <a href="#" class="button"><span>Normal Button</span></a>
                    <a href="#" class="large button"><span>Large Button</span></a>
                </div>
                <div class="col_4">
                    <a href="#" class="small black button"><span>Small Button</span></a>
                    <a href="#" class="button black"><span>Normal Button</span></a>
                    <a href="#" class="large button black"><span>Large Button</span></a>
                </div>
                <div class="col_4 last">
                    <a href="#" class="small blue button"><span>Small Button</span></a>
                    <a href="#" class="blue button"><span>Normal Button</span></a>
                    <a href="#" class="large blue button"><span>Large Button</span></a>
                </div>
            </div>
        </div>
    </div>
</div>
    
</div>

<?php include "footer.php"; ?>
