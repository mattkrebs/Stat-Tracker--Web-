<?php
if(isset($_GET['sidebar'])){
    include('s_header.php');
} else {
    include('header.php');
}
?>

<div id="titlediv">
    <div class="clearfix container" id="pattern">
        <div class="row">
            <div class="col_12">
                <ul class="breadcrumbs hor-list">
                    <li><a href="index.php">Dashboard</a></li>
                </ul>
                <h1>Dashboard</h1>
            </div>
        </div>
    </div>
</div>

<div class="container" id="actualbody">

<div class="row clearfix"><div class="col_12">
    <div class="widget clearfix">
        <h2>Report</h2>
        <div class="widget_inside">
            
            <h3>Current Statistics</h3>
            
            <div class="report">
                <div class="button up">
                    <span class="value">1,337</span>
                    <span class="attr">Views</span>
                </div>
                <div class="button down">
                    <span class="value">9,001</span>
                    <span class="attr">Pageviews</span>
                </div>
                <div class="button">
                    <span class="value">3.142</span>
                    <span class="attr">Pages/Views</span>
                </div>
                <div class="button">
                    <span class="value">83%</span>
                    <span class="attr">Bounce Rate</span>
                </div>
                <div class="button">
                    <span class="value">00:00:33</span>
                    <span class="attr">Avg. Time on Site</span>
                </div>
                <div class="button">
                    <span class="value">42%</span>
                    <span class="attr">New Visits</span>
                </div>
            </div>
            
            <div class="col_12">

                <p class="padding_bottom_15 padding_top_15">Flexible and interactive graphs, made with HTML5 and canvas. Check out more charts and graphs in our <a href="statistics.php">Statistics</a> page. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam a lectus non metus fringilla rhoncus. Nunc convallis, velit vitae adipiscing elementum, leo dolor bibendum est, sed dignissim neque diam in nisi. </p>
                
                <div id="chart" style="width: 100%; height: 280px"></div>
                <script type="text/javascript">
                    $(function () {
                             var data1 = [
                                {
                                    label: "Pageviews",
                                    data: [[1, 1513], [2, 1234], [3, 1643], [4, 1245], [5, 1263], [6, 1833], [7, 1944], [8, 1739], [9, 1545], [10, 2354], [11, 1254], [12, 1531],[13, 1413], [14, 1134], [15, 1133], [16, 1445], [17, 1663], [18, 1233], [19, 1244], [20, 1439], [21, 1635], [22, 1224], [23, 1154], [23, 1021], [24, 931] ]
                                },
                                {
                                    label: "Visits", 
                                    data: [[1, 1413], [2, 1134], [3, 1133], [4, 1445], [5, 1663], [6, 1233], [7, 1244], [8, 1439], [9, 1635], [10, 2124], [11, 1554], [12, 1521],[13, 1513], [14, 1234], [15, 1643], [16, 1245], [17, 1263], [18, 1833], [19, 1944], [20, 1739], [21, 1545], [22, 2354], [23, 1254], [24, 1531]]
                                }
                            ];

                            $.plot($("#chart"), data1, {
                                   grid: {backgroundColor: { colors: ["#fff", "#fff"] } },
                                   colors: ["#2266BB", "#FF9115"]
                                });
                            
                        });
                </script>
            </div>
        </div>
    </div>
</div></div>

<div class="row clearfix"><div class="col_12">
    <div class="widget clearfix">
        <h2>Data Table</h2>
        <div class="widget_inside">
            <p>DataTable? Regular Table? Everything is ready for you to start using right now! Check out the <a href="tables.php">Tables</a> page!</p> <br />
            <div class="col_12">
                <table class='dataTable'>
                <thead>
                        <tr>

                            <th></th>
                                <th class="align-left">Rendering engine</th>
                                <th class="align-left">Browser</th>
                                <th class="align-left">Platform(s)</th>
                                <th>Engine version</th>
                                <th>CSS grade</th>

                        </tr>
                    </thead>
                    <tbody>
                        <tr class="gradeX">
                            <td><input type="checkbox" /></td>
                                <td>Trident</td>
                                <td>Internet
                                         Explorer 4.0</td>

                                <td>Win 95+</td>
                                <td class="center">4</td>
                                <td class="center">X</td>
                        </tr>
                        <tr class="gradeC">
                            <td><input type="checkbox" /></td>
                                <td>Trident</td>

                                <td>Internet Explorer 5.0</td>
                                <td>Win 95+</td>
                                <td class="center">5</td>
                                <td class="center">C</td>
                        </tr>
                        <tr class="gradeA">
                            <td><input type="checkbox" /></td>

                                <td>Trident</td>
                                <td>Internet
                                         Explorer 5.5</td>

                                <td>Win 95+</td>
                                <td class="center">5.5</td>
                                <td class="center">A</td>
                        </tr>

                        <tr class="gradeA">
                            <td><input type="checkbox" /></td>
                                <td>Trident</td>
                                <td>Internet
                                         Explorer 6</td>

                                <td>Win 98+</td>
                                <td class="center">6</td>

                                <td class="center">A</td>
                        </tr>
                        <tr class="gradeA">
                            <td><input type="checkbox" /></td>
                                <td>Trident</td>
                                <td>Internet Explorer 7</td>

                                <td>Win XP SP2+</td>

                                <td class="center">7</td>
                                <td class="center">A</td>
                        </tr>
                        <tr class="gradeA">
                            <td><input type="checkbox" /></td>
                                <td>Trident</td>
                                <td>AOL browser (AOL desktop)</td>

                                <td>Win XP</td>
                                <td class="center">6</td>
                                <td class="center">A</td>
                        </tr>
                        <tr class="gradeA">
                            <td><input type="checkbox" /></td>
                                <td>Gecko</td>

                                <td>Firefox 1.0</td>

                                <td>Win 98+ / OSX.2+</td>
                                <td class="center">1.7</td>
                                <td class="center">A</td>
                        </tr>
                        <tr class="gradeA">

                            <td><input type="checkbox" /></td>
                                <td>Gecko</td>
                                <td>Firefox 1.5</td>

                                <td>Win 98+ / OSX.2+</td>
                                <td class="center">1.8</td>
                                <td class="center">A</td>

                        </tr>
                        <tr class="gradeA">
                            <td><input type="checkbox" /></td>
                                <td>Gecko</td>
                                <td>Firefox 2.0</td>

                                <td>Win 98+ / OSX.2+</td>
                                <td class="center">1.8</td>

                                <td class="center">A</td>
                        </tr>
                        <tr class="gradeA">
                            <td><input type="checkbox" /></td>
                                <td>Gecko</td>
                                <td>Firefox 3.0</td>

                                <td>Win 2k+ / OSX.3+</td>

                                <td class="center">1.9</td>
                                <td class="center">A</td>
                        </tr>
                        <tr class="gradeA">
                            <td><input type="checkbox" /></td>
                                <td>Gecko</td>
                                <td>Camino 1.0</td>

                                <td>OSX.2+</td>
                                <td class="center">1.8</td>
                                <td class="center">A</td>
                        </tr>
                        <tr class="gradeA">
                            <td><input type="checkbox" /></td>
                                <td>Gecko</td>

                                <td>Camino 1.5</td>

                                <td>OSX.3+</td>
                                <td class="center">1.8</td>
                                <td class="center">A</td>
                        </tr>
                        <tr class="gradeA">

                            <td><input type="checkbox" /></td>
                                <td>Gecko</td>
                                <td>Netscape 7.2</td>

                                <td>Win 95+ / Mac OS 8.6-9.2</td>
                                <td class="center">1.7</td>
                                <td class="center">A</td>

                        </tr>
                        <tr class="gradeA">
                            <td><input type="checkbox" /></td>
                                <td>Gecko</td>
                                <td>Netscape Browser 8</td>

                                <td>Win 98SE+</td>
                                <td class="center">1.7</td>

                                <td class="center">A</td>
                        </tr>
                        <tr class="gradeA">
                            <td><input type="checkbox" /></td>
                                <td>Gecko</td>
                                <td>Netscape Navigator 9</td>

                                <td>Win 98+ / OSX.2+</td>

                                <td class="center">1.8</td>
                                <td class="center">A</td>
                        </tr>
                        <tr class="gradeA">
                            <td><input type="checkbox" /></td>
                                <td>Gecko</td>
                                <td>Mozilla 1.0</td>

                                <td>Win 95+ / OSX.1+</td>
                                <td class="center">1</td>
                                <td class="center">A</td>
                        </tr>
                        <tr class="gradeA">
                            <td><input type="checkbox" /></td>
                                <td>Gecko</td>

                                <td>Mozilla 1.1</td>

                                <td>Win 95+ / OSX.1+</td>
                                <td class="center">1.1</td>
                                <td class="center">A</td>
                        </tr>
                        <tr class="gradeA">

                            <td><input type="checkbox" /></td>
                                <td>Gecko</td>
                                <td>Mozilla 1.2</td>

                                <td>Win 95+ / OSX.1+</td>
                                <td class="center">1.2</td>
                                <td class="center">A</td>

                        </tr>
                        <tr class="gradeA">
                            <td><input type="checkbox" /></td>
                                <td>Gecko</td>
                                <td>Mozilla 1.3</td>

                                <td>Win 95+ / OSX.1+</td>
                                <td class="center">1.3</td>

                                <td class="center">A</td>
                        </tr>
                        <tr class="gradeA">
                            <td><input type="checkbox" /></td>
                                <td>Gecko</td>
                                <td>Mozilla 1.4</td>

                                <td>Win 95+ / OSX.1+</td>

                                <td class="center">1.4</td>
                                <td class="center">A</td>
                        </tr>
                        <tr class="gradeA">
                            <td><input type="checkbox" /></td>
                                <td>Gecko</td>
                                <td>Mozilla 1.5</td>

                                <td>Win 95+ / OSX.1+</td>
                                <td class="center">1.5</td>
                                <td class="center">A</td>
                        </tr>
                        <tr class="gradeA">
                            <td><input type="checkbox" /></td>
                                <td>Gecko</td>

                                <td>Mozilla 1.6</td>

                                <td>Win 95+ / OSX.1+</td>
                                <td class="center">1.6</td>
                                <td class="center">A</td>
                        </tr>
                        <tr class="gradeA">

                            <td><input type="checkbox" /></td>
                                <td>Gecko</td>
                                <td>Mozilla 1.7</td>

                                <td>Win 98+ / OSX.1+</td>
                                <td class="center">1.7</td>
                                <td class="center">A</td>

                        </tr>
                        <tr class="gradeA">
                            <td><input type="checkbox" /></td>
                                <td>Gecko</td>
                                <td>Mozilla 1.8</td>

                                <td>Win 98+ / OSX.1+</td>
                                <td class="center">1.8</td>

                                <td class="center">A</td>
                        </tr>
                        <tr class="gradeA">
                            <td><input type="checkbox" /></td>
                                <td>Gecko</td>
                                <td>Seamonkey 1.1</td>

                                <td>Win 98+ / OSX.2+</td>

                                <td class="center">1.8</td>
                                <td class="center">A</td>
                        </tr>
                        <tr class="gradeA">
                            <td><input type="checkbox" /></td>
                                <td>Gecko</td>
                                <td>Epiphany 2.20</td>

                                <td>Gnome</td>
                                <td class="center">1.8</td>
                                <td class="center">A</td>
                        </tr>
                        <tr class="gradeA">
                            <td><input type="checkbox" /></td>
                                <td>Webkit</td>

                                <td>Safari 1.2</td>

                                <td>OSX.3</td>
                                <td class="center">125.5</td>
                                <td class="center">A</td>
                        </tr>
                        <tr class="gradeA">

                            <td><input type="checkbox" /></td>
                                <td>Webkit</td>
                                <td>Safari 1.3</td>

                                <td>OSX.3</td>
                                <td class="center">312.8</td>
                                <td class="center">A</td>

                        </tr>
                        <tr class="gradeA">
                            <td><input type="checkbox" /></td>
                                <td>Webkit</td>
                                <td>Safari 2.0</td>

                                <td>OSX.4+</td>
                                <td class="center">419.3</td>

                                <td class="center">A</td>
                        </tr>
                        <tr class="gradeA">
                            <td><input type="checkbox" /></td>
                                <td>Webkit</td>
                                <td>Safari 3.0</td>

                                <td>OSX.4+</td>

                                <td class="center">522.1</td>
                                <td class="center">A</td>
                        </tr>
                        <tr class="gradeA">
                            <td><input type="checkbox" /></td>
                                <td>Webkit</td>
                                <td>OmniWeb 5.5</td>

                                <td>OSX.4+</td>
                                <td class="center">420</td>
                                <td class="center">A</td>
                        </tr>
                        <tr class="gradeA">
                            <td><input type="checkbox" /></td>
                                <td>Webkit</td>

                                <td>iPod Touch / iPhone</td>

                                <td>iPod</td>
                                <td class="center">420.1</td>
                                <td class="center">A</td>
                        </tr>
                        <tr class="gradeA">

                            <td><input type="checkbox" /></td>
                                <td>Webkit</td>
                                <td>S60</td>

                                <td>S60</td>
                                <td class="center">413</td>
                                <td class="center">A</td>

                        </tr>
                        <tr class="gradeA">
                            <td><input type="checkbox" /></td>
                                <td>Presto</td>
                                <td>Opera 7.0</td>

                                <td>Win 95+ / OSX.1+</td>
                                <td class="center">-</td>

                                <td class="center">A</td>
                        </tr>
                        <tr class="gradeA">
                            <td><input type="checkbox" /></td>
                                <td>Presto</td>
                                <td>Opera 7.5</td>

                                <td>Win 95+ / OSX.2+</td>

                                <td class="center">-</td>
                                <td class="center">A</td>
                        </tr>
                        <tr class="gradeA">
                            <td><input type="checkbox" /></td>
                                <td>Presto</td>
                                <td>Opera 8.0</td>

                                <td>Win 95+ / OSX.2+</td>
                                <td class="center">-</td>
                                <td class="center">A</td>
                        </tr>
                        <tr class="gradeA">
                            <td><input type="checkbox" /></td>
                                <td>Presto</td>

                                <td>Opera 8.5</td>

                                <td>Win 95+ / OSX.2+</td>
                                <td class="center">-</td>
                                <td class="center">A</td>
                        </tr>
                        <tr class="gradeA">

                            <td><input type="checkbox" /></td>
                                <td>Presto</td>
                                <td>Opera 9.0</td>

                                <td>Win 95+ / OSX.3+</td>
                                <td class="center">-</td>
                                <td class="center">A</td>

                        </tr>
                        <tr class="gradeA">
                            <td><input type="checkbox" /></td>
                                <td>Presto</td>
                                <td>Opera 9.2</td>

                                <td>Win 88+ / OSX.3+</td>
                                <td class="center">-</td>

                                <td class="center">A</td>
                        </tr>
                        <tr class="gradeA">
                            <td><input type="checkbox" /></td>
                                <td>Presto</td>
                                <td>Opera 9.5</td>

                                <td>Win 88+ / OSX.3+</td>

                                <td class="center">-</td>
                                <td class="center">A</td>
                        </tr>
                        <tr class="gradeA">
                            <td><input type="checkbox" /></td>
                                <td>Presto</td>
                                <td>Opera for Wii</td>

                                <td>Wii</td>
                                <td class="center">-</td>
                                <td class="center">A</td>
                        </tr>
                        <tr class="gradeA">
                            <td><input type="checkbox" /></td>
                                <td>Presto</td>

                                <td>Nokia N800</td>

                                <td>N800</td>
                                <td class="center">-</td>
                                <td class="center">A</td>
                        </tr>
                        <tr class="gradeA">

                            <td><input type="checkbox" /></td>
                                <td>Presto</td>
                                <td>Nintendo DS browser</td>

                                <td>Nintendo DS</td>
                                <td class="center">8.5</td>
                                <td class="center">C/A<sup>1</sup></td>

                        </tr>
                        <tr class="gradeC">
                            <td><input type="checkbox" /></td>
                                <td>KHTML</td>

                                <td>Konqureror 3.1</td>
                                <td>KDE 3.1</td>
                                <td class="center">3.1</td>

                                <td class="center">C</td>
                        </tr>
                        <tr class="gradeA">
                            <td><input type="checkbox" /></td>
                                <td>KHTML</td>

                                <td>Konqureror 3.3</td>
                                <td>KDE 3.3</td>

                                <td class="center">3.3</td>
                                <td class="center">A</td>
                        </tr>
                        <tr class="gradeA">
                            <td><input type="checkbox" /></td>
                                <td>KHTML</td>

                                <td>Konqureror 3.5</td>

                                <td>KDE 3.5</td>
                                <td class="center">3.5</td>
                                <td class="center">A</td>
                        </tr>
                        <tr class="gradeX">
                            <td><input type="checkbox" /></td>
                                <td>Tasman</td>

                                <td>Internet Explorer 4.5</td>
                                <td>Mac OS 8-9</td>
                                <td class="center">-</td>
                                <td class="center">X</td>
                        </tr>
                        <tr class="gradeC">

                            <td><input type="checkbox" /></td>
                                <td>Tasman</td>

                                <td>Internet Explorer 5.1</td>
                                <td>Mac OS 7.6-9</td>
                                <td class="center">1</td>
                                <td class="center">C</td>

                        </tr>
                        <tr class="gradeC">
                            <td><input type="checkbox" /></td>
                                <td>Tasman</td>

                                <td>Internet Explorer 5.2</td>
                                <td>Mac OS 8-X</td>
                                <td class="center">1</td>

                                <td class="center">C</td>
                        </tr>
                        <tr class="gradeA">
                            <td><input type="checkbox" /></td>
                                <td>Misc</td>

                                <td>NetFront 3.1</td>
                                <td>Embedded devices</td>

                                <td class="center">-</td>
                                <td class="center">C</td>
                        </tr>
                        <tr class="gradeA">
                            <td><input type="checkbox" /></td>
                                <td>Misc</td>

                                <td>NetFront 3.4</td>

                                <td>Embedded devices</td>
                                <td class="center">-</td>
                                <td class="center">A</td>
                        </tr>
                        <tr class="gradeX">
                            <td><input type="checkbox" /></td>
                                <td>Misc</td>

                                <td>Dillo 0.8</td>
                                <td>Embedded devices</td>
                                <td class="center">-</td>
                                <td class="center">X</td>
                        </tr>
                        <tr class="gradeX">

                            <td><input type="checkbox" /></td>
                                <td>Misc</td>

                                <td>Links</td>
                                <td>Text only</td>
                                <td class="center">-</td>
                                <td class="center">X</td>

                        </tr>
                        <tr class="gradeX">
                            <td><input type="checkbox" /></td>
                                <td>Misc</td>

                                <td>Lynx</td>
                                <td>Text only</td>
                                <td class="center">-</td>

                                <td class="center">X</td>
                        </tr>
                        <tr class="gradeC">
                            <td><input type="checkbox" /></td>
                                <td>Misc</td>

                                <td>IE Mobile</td>
                                <td>Windows Mobile 6</td>

                                <td class="center">-</td>
                                <td class="center">C</td>
                        </tr>
                        <tr class="gradeC">
                            <td><input type="checkbox" /></td>
                                <td>Misc</td>
                                <td>PSP browser</td>

                                <td>PSP</td>
                                <td class="center">-</td>
                                <td class="center">C</td>
                        </tr>
                        <tr class="gradeU">
                            <td><input type="checkbox" /></td>
                            <td>Other browsers</td>

                            <td>All others</td>
                            <td>-</td>
                            <td class="center">-</td>
                            <td class="center">U</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div></div>
    
<div class="row clearfix"><div class="col_12">
    <div class="widget clearfix">
        <h2>Form Elements</h2>
        <div class="widget_inside">
        <div class="clearfix col_12">
            <div class="col_4">
                <h3>Default styles</h3>
                <p>Every admin theme needs a powerful yet subtle form design. This theme is no different. Check out the <a href="forms.php">Forms</a> page for client-side validation!</p>
            </div>
            <div class="col_8 last">
                <div class="form">
                    <div class="clearfix">
                        <label>Large Input</label>
                        <div class="input"><input class="large" type="text" /></div>
                    </div>
                    <div class="clearfix">
                        <label>Field with Tooltip</label>
                        <div class="input">
                            <input type="text" title="hello" rel="tooltips" class="xlarge" />
                            <span class="info">Specify a title attribute for tooltips</span>
                        </div>
                    </div>
                    <div class="clearfix">
                        <label>Placeholder Text</label>
                        <div class="input">
                            <input type="text" placeholder="This is a sample placeholder text" class="xxlarge" />
                            <span class="info">use the placeholder attribute <code>placeholder="your placeholder text"</code></span>
                        </div>
                    </div>
                    <div class="clearfix">
                        <label>Select</label>
                        <div class="input">
                            <select>
                                <option>Toyota</option>
                                <option>BMW</option>
                                <option>Ferrari</option>
                                <option>Lamborghini</option>
                                <option>Volvo</option>
                                <option>Mitsubishi</option>
                                <option>Tata</option>
                            </select>
                        </div>
                    </div>
                    <div class="clearfix">
                        <label>Multiple Select</label>
                        <div class="input">
                            <select multiple="">
                                <option>Toyota</option>
                                <option>BMW</option>
                                <option>Ferrari</option>
                                <option>Lamborghini</option>
                                <option>Volvo</option>
                                <option>Mitsubishi</option>
                                <option>Tata</option>
                            </select>
                        </div>
                    </div>
                    <div class="clearfix">
                        <label>Disabled Input</label>
                        <div class="input">
                            <input type="text" disabled="disabled" class="xlarge" value="This field is disabled, carry on..."></input>
                        </div>
                    </div>
                    <div class="clearfix red-highlight">
                        <label>Red Highlight</label>
                        <div class="input">
                            <input type="text" class="xlarge"></input>
                            <span class="help">Small snippet of help text</span>
                        </div>                        
                    </div>
                    <div class="clearfix green-highlight">
                        <label>Green Highlight</label>
                        <div class="input">
                            <input type="text" class="xlarge"></input>
                            <span class="help">Small snippet of help text</span>
                        </div>                        
                    </div>
                    <div class="clearfix">
                        <label>Textarea</label>
                        <div class="input"><textarea class="xxlarge"></textarea></div>
                    </div>
                    <div class="clearfix">
                        <label>Options</label>
                        <div class="input">
                            <input type="radio">Radio 1</input>
                            <input type="radio">Radio 2</input>
                            <input type="checkbox">Checkbox 1</input>
                            <input type="checkbox">Checkbox 2</input>
                        </div>
                    </div>
                    <div class="clearfix grey-highlight">
                        <div class="input no-label">
                            <input type="submit" class="button blue" value="Submit"></input>
                            <input type="reset" class="button grey" value="Reset"></input>
                        </div>
                    </div>
                </div>
            </div>
        </div>
            <div class="col_12">
                <h3 class="margin_bottom_15">Notification Messages</h3>
                <span class="notification undone">
                    This is a red notification with class="notification undone"
                </span>
                <span class="notification done">
                    This is a green notification with class="notification done"
                </span>
                <span class="notification information">
                    This is a blue notification with class="notification information"
                </span>
                <span class="notification setting">
                    This is a grey notification with class="notification settings"
                </span>
                <span class="notification warning">
                    This is a yellow notification with class="notification warning"
                </span>
            </div>
        </div>
    </div>   
</div></div>
            
<?php include("footer.php") ?>