<?php
if(isset($_GET['sidebar'])){
    include('s_header.php');
} else {
    include('header.php');
}
?>

<div id="titlediv">
    <div class="clearfix container" id="pattern">
        <div class="row">
            <div class="col_12">
                <ul class="breadcrumbs hor-list">
                    <li><a href="index.php">Dashboard</a></li>
                    <li><a href="dialogbox.php">Dialog Boxes</a></li>
                </ul>
                <h1>Dialog Boxes</h1>
            </div>
        </div>
    </div>
</div>

<div class="container" id="actualbody">

<div class="row clearfix">
    <div class="col_12">
        <div class="widget clearfix">
            <h2>Colorbox</h2>
            <script>
		$(document).ready(function(){
			//Examples of how to assign the ColorBox event to elements
			$(".group1").colorbox({rel:'group1'});
			$(".group2").colorbox({rel:'group2', transition:"fade"});
			$(".group3").colorbox({rel:'group3', transition:"none", width:"75%", height:"75%"});
			$(".group4").colorbox({rel:'group4', slideshow:true});
                        

                        $(".youtube").colorbox({iframe:true, innerWidth:425, innerHeight:344});
			$(".iframe").colorbox({iframe:true, width:"80%", height:"80%"});
			$(".inline").colorbox({inline:true, width:"50%"});
			$(".callbacks").colorbox({
				onOpen:function(){ alert('onOpen: colorbox is about to open'); },
				onLoad:function(){ alert('onLoad: colorbox has started to load the targeted content'); },
				onComplete:function(){ alert('onComplete: colorbox has displayed the loaded content'); },
				onCleanup:function(){ alert('onCleanup: colorbox has begun the close process'); },
				onClosed:function(){ alert('onClosed: colorbox has completely closed'); }
			});
                        
                        //Example of preserving a JavaScript event for inline calls.
			$("#click").click(function(){ 
				$('#click').css({"background-color":"#f00", "color":"#fff", "cursor":"inherit"}).text("Open this window again and this message will still be here.");
				return false;
			});
                });
            </script>
            <div class="widget_inside">
                <h3>Photos</h3>
                <div class="col_3">
                    <a class="group1" href="demo/1.jpg"><img src="demo/1.jpg" /></a>
                    <a class="group1 hide" href="demo/27.jpg"><img src="demo/27.jpg" /></a>
                    <a class="group1 hide" href="demo/33.jpg"><img src="demo/33.jpg" /></a>
                    <p class="center">Elastic Transition.</p>
                </div>
                <div class="col_3">
                    <a class="group2" href="demo/1.jpg"><img src="demo/1.jpg" /></a>
                    <a class="group2 hide" href="demo/27.jpg"><img src="demo/27.jpg" /></a>
                    <a class="group2 hide" href="demo/33.jpg"><img src="demo/33.jpg" /></a>
                    <p class="center">Fade Transition.</p>
                </div>
                <div class="col_3">
                    <a class="group3" href="demo/1.jpg"><img src="demo/1.jpg" /></a>
                    <a class="group3 hide" href="demo/27.jpg"><img src="demo/27.jpg" /></a>
                    <a class="group3 hide" href="demo/33.jpg"><img src="demo/33.jpg" /></a>
                    <p class="center">No Transition. Fixed Height and Width</p>
                </div>
                <div class="col_3 last">
                    <a class="group4" href="demo/1.jpg"><img src="demo/1.jpg" /></a>
                    <a class="group4 hide" href="demo/27.jpg"><img src="demo/27.jpg" /></a>
                    <a class="group4 hide" href="demo/33.jpg"><img src="demo/33.jpg" /></a>
                    <p class="center">Slideshow</p>
                </div>
                
                <h3 class="margin_top_15 margin_bottom_15">Other Content Types</h3>
                <div class="col_3">
                    <p><a class='button callbacks center' href="demo/5.jpg"><span>Callbacks</span></a></p>
                </div>
                <div class="col_3">
                    <a href="http://www.youtube.com/watch?v=PQMJCOT2wlQ" class="youtube button center" title="Persuit of Happiness (Kid CuDi Cover)"><span>Direct Link To YouTube</span></a>
                </div>
                <div class="col_3">
                    <a href="http://www.google.com/" class="iframe button center"><span>Outside HTML (Ajax)</span></a>
                </div>
                <div class="col_3 last">
                    <a href="#inline_content" class="inline button center"><span>Inline HTML</span></a>
                        <div style='display:none'>
                            <div id='inline_content' style='padding:10px; background:#fff;'>
                            <p><strong>This content comes from a hidden element on this page.</strong></p>
                            <p>The inline option preserves bound JavaScript events and changes, and it puts the content back where it came from when it is closed.</p>
                            <p><a id="click" href="#" style='padding:5px; background:#ccc;'>Click me, it will be preserved!</a></p>
                            </div>
                        </div>
                </div>
            </div>
        </div>
    </div>
</div>
    
    <div class="row clearfix">
        <div class="col_12">
            <div class="widget clearfix">
                <h2>jQueryUI</h2>
                <div class="widget_inside">
                    <div class="col_8">
                        <h3>Modal Dialog Box</h3>
                        <p>A dialog is a floating window that contains a title bar and a content area. The dialog window can be moved, resized and closed with the 'x' icon by default.</p>
                        <p>The following is an example of a modal dialog box, which prevents the user from interacting with the rest of the page until it is closed.</p>
                    </div>
                    <div class="col_4 last">
                        <div id="dialog_link">Open Modal Dialog</div>

                        <div id="dialog" title="Dialog Title">
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
</div>

<?php include('footer.php') ?>
