<?php include "header.php"; ?>

<div id="titlediv">
    <div class="clearfix container" id="pattern">
        <div class="row">
            <div class="col_12">
                <ul class="breadcrumbs hor-list">
                    <li><a href="index.php">Dashboard</a></li>
                    <li><a href="calendar.php">Calendar</a></li>
                </ul>
                <h1>Calendar</h1>
            </div>
        </div>
    </div>
</div>

<div class="container" id="actualbody">

<div class="row clearfix"><div class="col_12">
    <div class="widget clearfix">
        <h2>Basic Calendar</h2>
        <div class="widget_inside">
            <div class="col_3">
                <h3>Month/Week/Day views. Draggable events.</h3>
                <p>FullCalendar is a jQuery plugin that provides a full-sized, drag & drop calendar like the one on the side. It uses AJAX to fetch events on-the-fly for each month and is easily configured to use your own feed format</p>
                <p><a href="http://arshaw.com/fullcalendar/docs/usage/">Documentation</a></p>
            </div>
            <div class="col_9 last">
                <div id="calendar"></div>
            </div>
        </div>
    </div>
</div></div>

<div class="row clearfix"><div class="col_12">
    <div class="widget clearfix">
        <h2>Google Calendar</h2>
        <div class="widget_inside">
            <div class="col_3">
                <h3>Integrated</h3>
                <p>FullCalendar can display events from a public Google Calendar, which can serve as a backend that manages and persistently stores event data</p>
                <p><a href="http://arshaw.com/fullcalendar/docs/google_calendar/">Documentation</a></p>
            </div>
            <div class="col_9 last">
                <div id="gcalendar"></div>
            </div>
        </div>
    </div>
</div></div>



</div>
<?php include "footer.php"; ?>