<?php
if(isset($_GET['sidebar'])){
    include('s_header.php');
} else {
    include('header.php');
}
?>

<div id="titlediv">
    <div class="clearfix container" id="pattern">
        <div class="row">
            <div class="col_12">
                <ul class="breadcrumbs hor-list">
                    <li><a href="index.php">Dashboard</a></li>
                    <li><a href="grids.php">Grids</a></li>
                </ul>
                <h1>Grids</h1>
            </div>
        </div>
    </div>
</div>

<div class="container" id="actualbody">

<div class="row clearfix">
    <div class="col_12">
    <div class="widget clearfix">
        <h2>Col_12</h2>
        <div class="widget_inside">
            <p><strong>Muse</strong> uses Columnal grid system, which is a “remix” of a couple others with some custom code thrown in. </p>
            <p>Columnal makes responsive web design a little easier. It is 1140px wide, but since it is fluid, will respond to the width of most browsers.</p>
            <p>If the browser gets thin enough, the site will change to a mobile-friendly layout. <strong>Try resizing this page to give it a try (Internet Explorer 6-8 will be a fixed width page).</strong></p>
        </div>
    </div>
    </div>
</div>

<div class="row clearfix">
    <div class="col_3">
        <div class="widget clearfix">
            <h2>Col_3</h2>
            <div class="widget_inside">
                <p>Lorem Ipsum Dolor Sit Amet</p>
            </div>
        </div>
    </div>
    <div class="col_3">
        <div class="widget clearfix">
            <h2>Col_3</h2>
            <div class="widget_inside">
                <p>Lorem Ipsum Dolor Sit Amet</p>
            </div>
        </div>
    </div>
    <div class="col_6 last">
        <div class="widget clearfix">
            <h2>Col_6 last</h2>
            <div class="widget_inside">
                <p>A .last class is added for the last column in a row to remove margin-right</p>
            </div>
        </div>
    </div>
</div>
    
<div class="row clearfix">
    <div class="col_4">
            <div class="widget clearfix">
                <h2>Col_4</h2>
                <div class="widget_inside">
                    
                </div>
            </div>
    </div>
    <div class="col_2">
            <div class="widget clearfix">
                <h2>Col_2</h2>
                <div class="widget_inside">
                    
                </div>
            </div>
    </div>
    <div class="col_2">
            <div class="widget clearfix">
                <h2>Col_2</h2>
                <div class="widget_inside">
                    
                </div>
            </div>
    </div>
    <div class="col_4 last">
            <div class="widget clearfix">
                <h2>Col_4 last</h2>
                <div class="widget_inside">
                    
                </div>
            </div>
    </div>
</div>

<div class="row clearfix">
    <div class="col_12">
    <div class="widget clearfix">
        <h2>Columns on the inside</h2>
        <div class="widget_inside">
            <div class="col_6">
                <h3><code>.col_6</code></h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi malesuada euismod massa, in cursus tellus condimentum ut. Fusce lorem tortor, dictum nec facilisis in, vehicula vitae metus. Nullam suscipit metus vel arcu mattis vulputate. Praesent venenatis justo sit amet nulla pellentesque porttitor quis nec ante. Duis condimentum iaculis lacus ut cursus. Nulla iaculis arcu sed lectus elementum auctor. Aenean nec libero a lorem aliquam tempor. Duis vitae neque augue, id imperdiet metus. Proin viverra pellentesque semper. Etiam et lacus libero, id adipiscing mi. Mauris imperdiet ornare mattis. Duis nec sollicitudin sapien. Morbi in est elit, dictum bibendum dui. </p>
            </div>
            <div class="col_3">
                <h3><code>.col_3</code></h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi malesuada euismod massa, in cursus tellus condimentum ut. Fusce lorem tortor, dictum nec facilisis in, vehicula vitae metus. Nullam suscipit metus vel arcu mattis vulputate. Praesent venenatis justo sit amet nulla pellentesque porttitor quis nec ante. </p>
            </div>
            <div class="col_3 last">
                <h3><code>.col_3 last</code></h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi malesuada euismod massa, in cursus tellus condimentum ut. Fusce lorem tortor, dictum nec facilisis in, vehicula vitae metus. Nullam suscipit metus vel arcu mattis vulputate. Praesent venenatis justo sit amet nulla pellentesque porttitor quis nec ante. </p>
            </div>
        </div>
    </div>
    </div>
</div>
    
<div class="row clearfix">
    <div class="col_4">
            <div class="widget clearfix">
                <h2>Col_4</h2>
                <div class="widget_inside">
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi malesuada euismod massa, in cursus tellus condimentum ut. Fusce lorem tortor, dictum nec facilisis in, vehicula vitae metus. Nullam suscipit metus vel arcu mattis vulputate. Praesent venenatis justo sit amet nulla pellentesque porttitor quis nec ante. Fusce lorem tortor, dictum nec facilisis in. Praesent venenatis justo sit amet nulla pellentesque porttitor quis nec ante. Morbi malesuada euismod massa, in cursus tellus.</p>
                </div>
            </div>
    </div>
    <div class="col_5">
            <div class="widget clearfix">
                <h2>Col_5</h2>
                <div class="widget_inside">
                    <div class="col_3">
                        <h3><code>col_3</code></h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi malesuada euismod massa, in cursus tellus condimentum ut. Fusce lorem tortor, dictum nec facilisis in, vehicula vitae metus. Nullam suscipit metus vel arcu mattis vulputate.</p>
                    </div>
                    <div class="col_2 last">
                        <h3><code>col_2 last</code></h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi malesuada euismod massa, in cursus tellus condimentum ut. Fusce lorem tortor, dictum nec facilisis in. </p>
                    </div>
                </div>
            </div>
    </div>

    <div class="col_3 last">
            <div class="widget clearfix">
                <h2>Col_3 last</h2>
                <div class="widget_inside">
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi malesuada euismod massa, in cursus tellus condimentum ut. Fusce lorem tortor, dictum nec facilisis in, vehicula vitae metus. Nullam suscipit metus vel arcu mattis vulputate. Praesent venenatis justo sit amet nulla pellentesque porttitor quis nec ante. </p>
                </div>
            </div>
    </div>
</div>

</div>
<?php include "footer.php"; ?>
