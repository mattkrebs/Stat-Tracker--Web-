        </div><!--container -->
    </div>
</div>

<footer>
    <div class="container">
		<div class="row clearfix">
			<div class="col_12">
				<span class="left">&copy; 2011 Themio.</span>
				<span class="right">Powered by Muse</span>
			</div>
		</div>
    </div>
</footer>

</body>
</html>