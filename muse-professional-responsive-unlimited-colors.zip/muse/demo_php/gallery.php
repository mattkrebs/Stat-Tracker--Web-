<?php
if(isset($_GET['sidebar'])){
    include('s_header.php');
} else {
    include('header.php');
}
?>

<div id="titlediv">
    <div class="clearfix container" id="pattern">
        <div class="row">
            <div class="col_12">
                <ul class="breadcrumbs hor-list">
                    <li><a href="index.php">Dashboard</a></li>
                    <li><a href="gallery.php">Gallery</a></li>
                </ul>
                <h1>Gallery</h1>
            </div>
        </div>
    </div>
</div>

<div class="container" id="actualbody">

<div class="row">
    <div class="widget clearfix">
        <h2>Gallery</h2>
        <div class="widget_inside">
            <div class="col_12">
                <h3>Small Gallery</h3>
                <p>This is a small and default gallery, <code>ul class='gallery'</code></p>
                <p>Also, simply adding a <code>sortable</code> class to the gallery, or any list, to be sortable by simple drag-and-drop. Try it out!</p>
                
                <ul class="gallery sortable">
                    <li>
                        <img src="demo/11.jpg" />
                        <ul class="img_options">
                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>
                        </ul>
                    </li>
                    <li>
                        <img src="demo/12.jpg" />
                        <ul class="img_options">

                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>
                        </ul>
                    </li>
                    <li>
                        <img src="demo/13.jpg" />
                        <ul class="img_options">
                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>

                        </ul>
                    </li>
                    <li>
                        <img src="demo/14.jpg" />
                        <ul class="img_options">
                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>
                        </ul>

                    </li>
                    <li>
                        <img src="demo/15.jpg" />
                        <ul class="img_options">
                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>
                        </ul>
                    </li>

                    <li>
                        <img src="demo/16.jpg" />
                        <ul class="img_options">
                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>
                        </ul>
                    </li>
                    <li>

                        <img src="demo/17.jpg" />
                        <ul class="img_options">
                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>
                        </ul>
                    </li>
                    <li>
                        <img src="demo/18.jpg" />

                        <ul class="img_options">
                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>
                        </ul>
                    </li>
                    <li>
                        <img src="demo/19.jpg" />
                        <ul class="img_options">

                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>
                        </ul>
                    </li>
                    <li>
                        <img src="demo/20.jpg" />
                        <ul class="img_options">
                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>

                        </ul>
                    </li>
                    <li>
                        <img src="demo/21.jpg" />
                        <ul class="img_options">
                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>
                        </ul>

                    </li>
                    <li>
                        <img src="demo/22.jpg"  />
                        <ul class="img_options">
                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>
                        </ul>
                    </li>

                    <li>
                        <img src="demo/23.jpg" />
                        <ul class="img_options">
                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>
                        </ul>
                    </li>
                    <li>

                        <img src="demo/24.jpg" />
                        <ul class="img_options">
                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>
                        </ul>
                    </li>
                    <li>
                        <img src="demo/25.jpg" />

                        <ul class="img_options">
                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>
                        </ul>
                    </li>
                    <li>
                        <img src="demo/26.jpg" />
                        <ul class="img_options">

                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>
                        </ul>
                    </li>
                    <li>
                        <img src="demo/27.jpg" />
                        <ul class="img_options">
                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>

                        </ul>
                    </li>
                    <li>
                        <img src="demo/28.jpg" />
                        <ul class="img_options">
                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>
                        </ul>

                    </li>
                    <li>
                        <img src="demo/29.jpg" />
                        <ul class="img_options">
                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>
                        </ul>
                    </li>

                    <li>
                        <img src="demo/30.jpg" />
                        <ul class="img_options">
                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>
                        </ul>
                    </li>
                    <li>

                        <img src="demo/31.jpg" />
                        <ul class="img_options">
                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>
                        </ul>
                    </li>
                    <li>
                        <img src="demo/32.jpg" />

                        <ul class="img_options">
                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>
                        </ul>
                    </li>
                    <li>
                        <img src="demo/33.jpg" />
                        <ul class="img_options">

                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>
                        </ul>
                    </li>
                    <li>
                        <img src="demo/34.jpg"  />
                        <ul class="img_options">
                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>

                        </ul>
                    </li>
                    <li>
                        <img src="demo/35.jpg"  />
                        <ul class="img_options">
                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>
                        </ul>

                    </li>
                    <li>
                        <img src="demo/36.jpg"  />
                        <ul class="img_options">
                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
    
<div class="row">
    <div class="widget clearfix">
        <h2>Gallery</h2>
        <div class="widget_inside">
            <div class="col_12">
                <h3>Medium Gallery</h3>
                <p>This is a medium gallery, <code>ul class='gallery medium sortable'</code></p>
                <ul class="gallery medium sortable">
                    <li>
                        <img src="demo/11.jpg" />
                        <ul class="img_options">
                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>
                        </ul>
                    </li>
                    <li>
                        <img src="demo/12.jpg" />
                        <ul class="img_options">

                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>
                        </ul>
                    </li>
                    <li>
                        <img src="demo/13.jpg" />
                        <ul class="img_options">
                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>

                        </ul>
                    </li>
                    <li>
                        <img src="demo/14.jpg" />
                        <ul class="img_options">
                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>
                        </ul>

                    </li>
                    <li>
                        <img src="demo/15.jpg" />
                        <ul class="img_options">
                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>
                        </ul>
                    </li>

                    <li>
                        <img src="demo/16.jpg" />
                        <ul class="img_options">
                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>
                        </ul>
                    </li>
                    <li>

                        <img src="demo/17.jpg" />
                        <ul class="img_options">
                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>
                        </ul>
                    </li>
                    <li>
                        <img src="demo/18.jpg" />

                        <ul class="img_options">
                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>
                        </ul>
                    </li>
                    <li>
                        <img src="demo/19.jpg" />
                        <ul class="img_options">

                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>
                        </ul>
                    </li>
                    <li>
                        <img src="demo/20.jpg" />
                        <ul class="img_options">
                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>

                        </ul>
                    </li>
                    <li>
                        <img src="demo/21.jpg" />
                        <ul class="img_options">
                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>
                        </ul>

                    </li>
                    <li>
                        <img src="demo/22.jpg"  />
                        <ul class="img_options">
                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
    
<div class="row">
    <div class="widget clearfix">
        <h2>Gallery</h2>
        <div class="widget_inside">
            <div class="col_12">
                <h3>Large Gallery</h3>
                <p>This is a small and default gallery, <code>ul class='gallery large'</code></p>
                <p>Try resizing the window. If image is bigger than the browser, the image will resize itself! Perfect for those mobile browsers</p>
                <ul class="gallery large sortable">
                    <li>
                        <img src="demo/31.jpg" />
                        <ul class="img_options">
                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>
                        </ul>
                    </li>
                    <li>
                        <img src="demo/32.jpg" />

                        <ul class="img_options">
                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>
                        </ul>
                    </li>
                    <li>
                        <img src="demo/33.jpg" />
                        <ul class="img_options">

                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>
                        </ul>
                    </li>
                    <li>
                        <img src="demo/34.jpg"  />
                        <ul class="img_options">
                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>

                        </ul>
                    </li>
                    <li>
                        <img src="demo/28.jpg"  />
                        <ul class="img_options">
                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>
                        </ul>

                    </li>
                    <li>
                        <img src="demo/36.jpg"  />
                        <ul class="img_options">
                            <li><a href="#" class="btn">Edit</a></li> <li><a href="#" class="btn">Delete</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
    
</div>
    
<?php include("footer.php") ?>