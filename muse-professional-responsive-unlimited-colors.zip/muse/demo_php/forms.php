<?php
if(isset($_GET['sidebar'])){
    include('s_header.php');
} else {
    include('header.php');
}
?>

<div id="titlediv">
    <div class="clearfix container" id="pattern">
        <div class="row">
            <div class="col_12">
                <ul class="breadcrumbs hor-list">
                    <li><a href="index.php">Dashboard</a></li>
                    <li><a href="forms.php">Forms</a></li>
                </ul>
                <h1>Forms</h1>
            </div>
        </div>
    </div>
</div>

<div class="container" id="actualbody">

<div class="row">
    <div class="widget clearfix">
        <h2>Text Fields</h2>
        <div class="widget_inside">
            <div class="col_12">
            <div class="col_4">
                <h3>Default styles</h3>
                <p>All forms are given default styles to present them in a readable and scalable way. Styles are provided for text inputs, select lists, textareas, radio buttons and checkboxes, and buttons.</p>
                <p>Just use a class <code>.form</code> to a div or form element</p>
            </div>
            <div class="col_8 last">
                <div class="form">
                    <div class="clearfix">
                        <label>Large Input</label>
                        <div class="input"><input class="large" type="text" /></div>
                    </div>
                    <div class="clearfix">
                        <label>Field with Tooltip</label>
                        <div class="input">
                            <input type="text" title="hello" rel="tooltips" class="xlarge" />
                            <span class="info">Specify a title attribute for tooltips</span>
                        </div>
                    </div>
                    <div class="clearfix">
                        <label>Placeholder Text</label>
                        <div class="input">
                            <input type="text" placeholder="This is a sample placeholder text" class="xxlarge" />
                            <span class="info">use the placeholder attribute <code>placeholder="your placeholder text"</code></span>
                        </div>
                    </div>
                    <div class="clearfix">
                        <label>Select</label>
                        <div class="input">
                            <select>
                                <option>Toyota</option>
                                <option>BMW</option>
                                <option>Ferrari</option>
                                <option>Lamborghini</option>
                                <option>Volvo</option>
                                <option>Mitsubishi</option>
                                <option>Tata</option>
                            </select>
                        </div>
                    </div>
                    <div class="clearfix">
                        <label>Multiple Select</label>
                        <div class="input">
                            <select multiple="">
                                <option>Toyota</option>
                                <option>BMW</option>
                                <option>Ferrari</option>
                                <option>Lamborghini</option>
                                <option>Volvo</option>
                                <option>Mitsubishi</option>
                                <option>Tata</option>
                            </select>
                        </div>
                    </div>
                    <div class="clearfix">
                        <label>Disabled Input</label>
                        <div class="input">
                            <input type="text" disabled="disabled" class="xlarge" value="This field is disabled, carry on..."></input>
                        </div>
                    </div>
                    <div class="clearfix red-highlight">
                        <label>Red Highlight</label>
                        <div class="input">
                            <input type="text" class="xlarge"></input>
                            <span class="help">Small snippet of help text</span>
                        </div>                        
                    </div>
                    <div class="clearfix green-highlight">
                        <label>Green Highlight</label>
                        <div class="input">
                            <input type="text" class="xlarge"></input>
                            <span class="help">Small snippet of help text</span>
                        </div>                        
                    </div>
                    <div class="clearfix">
                        <label>Textarea</label>
                        <div class="input"><textarea class="xxlarge"></textarea></div>
                    </div>
                    <div class="clearfix">
                        <label>WYSIWYG Editor</label>
                        <div class="input"><textarea class="cleditor"></textarea></div>
                    </div>
                    <div class="clearfix">
                        <label>Multi-file Upload</label>
                        <div class="input"><input id="file_upload" name="file_upload" class="file_upload" /></div>
                    </div>
                    <div class="clearfix">
                        <label>Options</label>
                        <div class="input">
                            <input type="radio">Radio 1</input>
                            <input type="radio">Radio 2</input>
                            <input type="checkbox">Checkbox 1</input>
                            <input type="checkbox">Checkbox 2</input>
                        </div>
                    </div>
                    <div class="clearfix grey-highlight">
                        <div class="input no-label">
                            <input type="submit" class="button blue" value="Submit"></input>
                            <input type="reset" class="button grey" value="Reset"></input>
                        </div>
                    </div>
                </div>
            </div>
        </div>
            
            <div class="col_12">
                <div class="col_4">
                    <h3>Stacked forms</h3>
                    <p>Add <code>.stacked</code> to your <code>.form</code> and you’ll have labels on top of their fields instead of to their left. This works great if your forms are short or you have two columns of inputs for heavier forms.</p>
                    <p>Also, adding <code>.no-border</code> removes the border from the form</p>
                </div>
                <div class="col_8 last">
                    <div class="form stacked no-border">
                        <div class="clearfix">
                            <label>Large Input</label>
                            <div class="input"><input class="large" type="text" /></div>
                        </div>
                        <div class="clearfix">
                            <label>Field with Tooltip</label>
                            <div class="input">
                                <input type="text" title="hello" rel="tooltips" class="xlarge" />
                                <span class="info">Specify a title attribute for tooltips</span>
                            </div>
                        </div>
                        <div class="clearfix">
                            <label>Placeholder Text</label>
                            <div class="input">
                                <input type="text" placeholder="This is a sample placeholder text" class="xxlarge" />
                                <span class="info">use the placeholder attribute <code>placeholder="your placeholder text"</code></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>   
</div>
    
<div class="row">
    <div class="widget clearfix">
        <h2>jQuery UI</h2>
        <style type="text/css">
            /* CSS used for demo */
            ul#icons { margin: 0; padding: 0;}
            ul#icons li { margin: 2px; position: relative; padding: 4px 0; cursor: pointer; float: left; list-style: none; }
            ul#icons span.ui-icon { float: left; margin: 0 4px; }
            #eq span { height: 120px; float: left; margin: 15px; }
        </style>
        <div class="widget_inside">
            <div class="col_12">
                <div class="col_4">
                    <h3>Autocomplete</h3>
                    <p>The Autocomplete widgets provides suggestions while you type into the field. Here the suggestions are tags for countries. Start typing al for Albania or Algeria</p>
                </div>
                <div class="col_8 last">
                    <label for="countries">Countries: </label>
                    <input id="countries" type="text" />
                </div>
            </div>
            <div class="col_12">
                <div class="col_4">
                    <h3>Datepicker</h3>
                    <p>The jQuery UI Datepicker is a highly configurable plugin that adds datepicker functionality to your pages. You can customize the date format and language, restrict the selectable date ranges and add in buttons and other navigation options easily.</p>
                </div>
                <div class="col_8 last">
                    <div id="datepicker"></div>
                </div>
            </div>
            <div class="col_12">
                <div class="col_4">
                    <h3>Sliders</h3>
                    <p>The jQuery UI Slider plugin makes selected elements into sliders. There are various options such as multiple handles, and ranges. The handle can be moved with the mouse or the arrow keys.</p>
                </div>
                <div class="col_8 last">
                    <div class="col_4">
                        <div id="eq">
                            <span>88</span>
                            <span>77</span>
                            <span>55</span>
                            <span>33</span>
                            <span>40</span>
                            <span>45</span>
                            <span>70</span>
                        </div>
                    </div>
                    <div class="col_4 last">
                        <div id="horizSlider"></div>
                    </div>
                </div>
            </div>
            
            <div class="col_12">
                <div class="col_4">
                    <h3>Progressbar</h3>
                    <p>The progress bar is designed to simply display the current % complete for a process. The bar is coded to be flexibly sized through CSS and will scale to fit inside it's parent container by default.</p>
                </div>
                <div class="col_8 last">
                    <div id="progressbar"></div>
                    <br />
                    <a id="animateProgress" href="#">Animate to random number</a>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="widget clearfix">
        <h2>Validation</h2>
        <div class="widget_inside">
            <div class="col_12">
                <div class="col_4">
                    <h3>Required</h3>
                    <p>Just adding a class of <code>validate[required]</code> will force user to fill the field</p>
                </div>
                <div class="col_8 last">
                    <form class="form" id="form0">
                        <div class="clearfix">
                            <label>Field is required</label>
                            <div class="input"><input type="text" id="req" class="validate[required]" value="">
                                <span class="info"><code>class="validate[required]"</code></span>
                            </div>
                        </div>
                        <div class="clearfix">
                            <label>Favorite Sport 1</label>
                            <div class="input"><select id="sport1" class="validate[required]"><option>Tennis</option><option>Football</option><option>Golf</option></select>
                                <span class="info"><code>class="validate[required]"</code></span>
                            </div>
                        </div>
                        <div class="clearfix">
                            <label>Favorite Sport 2</label>
                            <div class="input"><select id="sport2" multiple="" class="validate[required]"><option>Tennis</option><option>Football</option><option>Golf</option></select>
                                <span class="info"><code>class="validate[required]"</code></span>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col_12">
                <div class="col_4">
                    <h3>Custom</h3>
                    <p>The validation engine can be customized with many predefined regex, for example <code>validate[required,custom[url]] </code></p>
                </div>
                <div class="col_8 last">
                    <form class="form" id="form1">
                        <div class="clearfix">
                            <label>Phone</label>
                            <div class="input">
                                <input id="telephone" type="text" class="validate[custom[phone]] xlarge" value="+1 305 768 23 34 ext 23 BUG"/>
                                <span class="info"><code>class="validate[custom[phone]]"</code></span>
                            </div>
                        </div>
                        <div class="clearfix">
                            <label>URL</label>
                            <div class="input">
                                <input id="url" type="text" class="validate[required,custom[url]] xlarge" value="http://"/>
                                <span class="info"><code>class="validate[required,custom[url]]"</code></span>
                            </div>
                        </div>
                        <div class="clearfix">
                            <label>Email</label>
                            <div class="input">
                                <input id="email" type="text" class="validate[required,custom[email]] xlarge" value="forced@error"/>
                                <span class="info"><code>class="validate[required,custom[email]]"</code></span>
                            </div>
                        </div>
                        <div class="clearfix">
                            <label>IPv4</label>
                            <div class="input">
                                <input id="ipv4" type="text" class="validate[required,custom[ipv4]] xlarge" value="172.0.1."/>
                                <span class="info"><code>class="validate[required,custom[ipv4]]"</code></span>
                            </div>
                        </div>
                        <div class="clearfix">
                            <label>Date</label>
                            <div class="input">
                                <input id="date" type="text" class="validate[required,custom[date]] xlarge" value="201-12-01" />
                                <span class="info"><code>class="validate[required,custom[date]]"</code></span>
                            </div>
                        </div>
                        <div class="clearfix">
                            <label>Number</label>
                            <div class="input">
                                <input id="number" type="text" class="validate[required,custom[number]] xlarge" value="-33.87a"/>
                                <span class="info"><code>class="validate[required,custom[number]]"</code></span>
                            </div>
                        </div>
                        <div class="clearfix">
                            <label>Integer</label>
                            <div class="input">
                                <input id="integer" type="text" class="validate[required,custom[integer]] xlarge" value="10.1"/>
                                <span class="info"><code>class="validate[required,custom[integer]]"</code></span>
                            </div>
                        </div>
                        <div class="clearfix">
                            <label>Only Alphanumeric</label>
                            <div class="input">
                                <input id="onlyLetterNumber" type="text" class="validate[required,custom[onlyLetterNumber]] xlarge" value="too many spaces obviously"/>
                                <span class="info"><code>class="validate[required,custom[onlyLetterNumber]]"</code></span>
                            </div>
                        </div>
                        <div class="clearfix">
                            <label>Only Numeric and Space</label>
                            <div class="input">
                                <input id="onlyNumberSp" type="text" class="validate[required,custom[onlyNumberSp]] xlarge" value="10.1"/>
                                <span class="info"><code>class="validate[required,custom[onlyNumberSp]]"</code></span>
                            </div>
                        </div>
                        <div class="clearfix">
                            <label>Only ASCII letters and Space</label>
                            <div class="input">
                                <input id="onlyascii" type="text" class="validate[required,custom[onlyLetterSp]] xlarge" value="this is an invalid char '.'" />
                                <span class="info"><code>class="validate[required,custom[onlyLetterSp]]"</code></span>
                            </div>
                        </div>
                        <div class="clearfix">
                            <span class="info">Need to make custom validations? You can with <a href="http://gskinner.com/RegExr/">regex</a>! Detailed documentation on form validator is located <a href="http://www.position-absolute.com/articles/jquery-form-validator-because-form-validation-is-a-mess/">here</a></span>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col_12">
                <div class="col_4">
                    <h3>Equals</h3>
                    <p>Both the fields much be exactly the same</p>
                </div>
                <div class="col_8 last">
                    <form class="form" id="form2">
                        <div class="clearfix">
                            <div class="input">
                                <label>Password : </label>
                                <div class="input"><input type="password" id="password" class="validate[required]" value="karnius" /></div>
                            </div>
                        </div>
                        <div class="clearfix">
                            <div class="input">
                                <label>Confirm password : </label>
                                <div class="input"><input type="password" id="password2"  class="validate[required,equals[password]]" value="kaniusBAD" /></div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


<?php include "footer.php"; ?>
