Muse v2.0
by Themio

http://themio.net
http://themeforest.net/item/muse-professional-responsive-unlimited-colors/667399

Muse is a beautifully coded full featured admin panel theme ready to be implemented in the back end of your application, or as an intranet theme! What sets this theme apart is the fact that it doesn't come with presets, rather gives you the ability to choose <strong><em>any</em></strong> color combination you want, making it truly, an unlimited color theme!

The theme uses HTML5 and CSS3 and degrades gracefully into older browsers, while using jQuery to build in interaction. Included are the PSDs as well as all the source files and all the icons that are used so you can extend the theme in whatever way you like.

Folder Structure
================
Support files
	_docs/
	_graphics/
Demos
	demo_php/
	demo_html/
Barebons
	barebone_html/



Changelog
=========
14th October 2011
	v1.0 Initial Relase
20th October 2011
	v1.1 Maintainence release
		Updated Login Page
14th November 2011
	v2.0 Sidebar Version
		Multi-file upload
		Bugfixes


Support
=======
Please send an email at themio@leevio.com and we will try to get back to you at the earliest possible time!

Like our theme? Give your honest rating at themeforest! But if you suffered any problems, please let us fix them for you first!

We'd also like to see how you have customized our theme for your use. Send as a screenshot for karma :)